
        (function(){

            "use strict";
            console.log('reading js');

           /* //var aVariable = "this is global";

            function testScope (){
            var aVariable = "this is local";
            console.log(aVariable);
         }

            testScope(); // furn the function

            console.log(aVariable);   
            */

            // const cheese = "yummy";
            // console.log(cheese);
            // cheese = "cheese is yucky";


            // for( let i=0; i<10; i ++) {
            //     console.log(i);
            // }
            // console.log(`the value of i is ${i}`);

            // console.log(cheese);
            // const cheese =  "yummy";

            document.querySelector('p').style.color = 'green';



        })();